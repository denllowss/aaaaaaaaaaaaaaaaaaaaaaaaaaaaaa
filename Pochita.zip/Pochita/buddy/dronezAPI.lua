--[[__  ___                      __
   /  |/  /_  ________________ _/ /_
  / /|_/ / / / / ___/ ___/ __ `/ __/
 / /  / / /_/ (__  ) /__/ /_/ / /_
/_/  /_/\__,_/____/\___/\__,_/\__]]
local C, utils                                       = require("buddy.config"), require("buddy.utils")
local dronezAPI, Particles, Instances, entityObjects = {}, {}, {}, {}
local entityObjectsCount                             = 0
local modelinstances                                 = models:newPart("dronezAPI" ..
	client.intUUIDToString(client.generateUUID())):setParentType("World"):newPart("Instances")
local deadly, hotty                                  = { "void", "spike", "molten", "saw", "cutter" }, { "lava", "fire" }
local not1x1Block                                    = { "carpet", "stonecutter", "conduit", "trapdoor",
	"daylight_detector", "slab",
	"head", "egg", "pot", "lantern", "lectern", "chorus", "amethyst", "dripstone", "candle", "camfire", "bed",
	"brewing_stand", "lily_pad", "minecraft:snow", "stair", "bamboo", "rod", "comparator", "repeater", "campfire" }
local mat4                                           = matrices.mat4()
local vec3                                           = vectors.vec3()
-->====================[ AI tick ]====================<----MADE BY @SOOMUCHLAG and @GNamimates EDIT BY @Muscat
function updateEntity(self, entity, name)
	local update = false
	local extra = self.extraData[name]
	if type(extra) == 'string' then extra = self.extraData[extra] end
	if extra then
		local vars = extra[1]()
		for i, v in pairs(vars) do
			if self.extraVars[i] ~= v then
				self.extraVars = vars
				update = true
				break
			end
		end
		if update then
			local nbt = extra[2]()
			pcall(entity.setNbt, entity, name, toJson(nbt))
		end
	end
end

--Interaction with Drone
local function droneInteraction(self, size, looking, rayPos, headPos)
	local isPunched, isLove = false, false
	for _, interactor in pairs(world.getEntities(self.pos - 4, self.pos + 4)) do
		local pos = interactor:getPos()
		for _, interactorPlayer in pairs(world.getPlayers()) do
			if interactorPlayer:getSwingTime() == 1 then
				local eyePos = vec(pos.x, pos.y + interactorPlayer:getEyeHeight(), pos.z)
				if raycast:aabb(eyePos, eyePos + interactorPlayer:getLookDir() * 3.5, { { self.pos - size, self.pos + size } }) and interactorPlayer:getHeldItem(interactorPlayer:isLeftHanded()).id ~= "minecraft:air" then
					if self.avatar == true then
						isPunched = false
					else
						isPunched = true
					end

					self.vel = self.vel + interactorPlayer:getLookDir() * self.punchImpulse * 2
				elseif raycast:aabb(eyePos, eyePos + interactorPlayer:getLookDir() * 3.5, { { headPos - size, headPos + size } }) and interactorPlayer:getHeldItem(interactorPlayer:isLeftHanded()).id == "minecraft:air" then
					if self.avatar == true then
						isLove = false
					else
						isLove = true
					end
					--elseif interactorPlayer:getHeldItem().id:find("golden_apple") then
					--pings.dronezAPI_syncCreate()
				end
			end
			if (looking and (self.pos - rayPos):length() < 2) then
				self.vel = self.vel + vec(0.02, 0, 0.02) * (self.pos - rayPos):normalized()
			end
		end

		if self.is_attacking and interactor ~= "minecraft:player" and ((self.pos - pos):length() > 0) then
			self.vel = self.vel - vec(0.05, 0, 0.05) * (self.pos - pos):normalized()
		elseif ((self.pos - pos):length() < 0.5) then
			self.vel = self.vel +
				self.acceleration * (self.pos - pos):normalized() / math.max((self.pos - pos):length() ^ 2, 0.5)
		end
	end
	return isPunched, isLove
end

---Changes the next note in the path to move to and adds velocity in the direction of the next node of the path
local function droneMovement(self, targetPos)
	self.pos = self.pos + self.vel
	local velocityToRotateTo = nil
	if self.path ~= nil and self.nextpathnode <= #self.path then self.curNode = self.path[self.nextpathnode] end
	if self.vel:length() > self.maxVelocity then
		self.vel.x, self.vel.y, self.vel.z = self.maxVelocity, self.maxVelocity, self.maxVelocity
	end
	--controll mode
	if self.engine then
		self.is_preattack = utils.is_holding_sword
		self.is_attacking = utils.is_attacking
		velocityToRotateTo = nil
	else
		if (self.path ~= nil and self.nextpathnode <= #self.path and self.curNode ~= nil) then
			if (self.pos - self.curNode):length() <= 1.3 then
				self.nextpathnode = self.nextpathnode + 1
				if self.nextpathnode <= #self.path then self.curNode = self.path[self.nextpathnode] end
			end
			velocityToRotateTo = (vec(-self.pos.x, -self.pos.y, -self.pos.z) + vec(self.curNode.x + 0.5, self.curNode.y + 0.5, self.curNode.z + 0.5))
				:normalize() * self.acceleration
			self.vel = self.vel + velocityToRotateTo
		end
		--entity attack
		if utils.nearestEntity(self.pos, 8) and C.noOwner(utils.nearestEntity(self.pos, 8)) and self.targetEntity ~= player then
			if (world:getTime() + self.index * 20) % 40 == 0 then
				self.is_preattack = true
			elseif (world:getTime() + self.index * 20) % 20 == 0 then
				self.is_preattack = false
			end
		end
		if utils.nearestEntity(self.pos, 3) and C.noOwner(utils.nearestEntity(self.pos, 3)) and self.targetEntity ~= player then
			self.is_attacking = true
		else
			self.is_attacking = false
		end
	end
	--log(self.is_preattack)
	--entity physics
	if not self.is_underwater and self.g == self.wjg then
		if self.is_jumping then
			self.g = self.jg
		else
			self.g = self.ng
		end
	end

	local block = world.getBlockState(self.pos + vec(0, -0.1, 0))
	if block:hasCollision() then
		self.floor_block = block
		self.a_f = 0.85
	else
		self.a_f = 0.9
		self.floor_block = nil
	end

	if self.is_underwater then
		if not #world.getBlockState(targetPos + vec(0, 4, 0)):getFluidTags() ~= 0 then
			self.vel.y = 0.1
			for _ = 1, 5 do
				particles:newParticle(
					self.block_inside.id:find("lava") and "minecraft:lava" or "minecraft:splash",
					self.pos + vec(math.random(-1, 1) / 2, 0, math.random(-1, 1) / 2)):setSize(1):setLifetime(50)
			end
		elseif self.engine then
			self.a_f = 0.85
			self.vel.y = self.vel.y - self.g * 0.9
		end
	else
		if self.ai == "Ground" then
			self.vel.y = self.vel.y + self.g
		elseif self.ai == "Air" then
			self.vel.y = self.vel.y * self.a_f
		end
	end

	local temppos = vec(self.posOld.x, self.posOld.y, self.posOld.z)

	local _, hitPos2, _ = raycast:block(vec(temppos.x, temppos.y, temppos.z),
		vec(self.pos.x, temppos.y, temppos.z))

	if hitPos2.x ~= self.pos.x then
		self.pos.x = hitPos2.x -
			math.sign(self.pos.x - self.posOld.x) * 0.01
		temppos.x = hitPos2.x
	end

	local _, hitPos3, _ = raycast:block(vec(temppos.x, temppos.y, temppos.z),
		vec(temppos.x, temppos.y, self.pos.z))

	if hitPos3.z ~= self.pos.z then
		self.pos.z = hitPos3.z -
			math.sign(self.pos.z - self.posOld.z) * 0.01
		temppos.z = hitPos3.z
	end
	---Does Y collision
	do
		if world.getBlockState(self.pos + vec(self.collisionoffset.x, -0.1, self.collisionoffset.y)):hasCollision() then
			self.vel.y       = 0
			self.pos.y       = math.ceil(self.pos.y - 0.3)
			self.is_on_floor = true
		else
			self.is_on_floor = false
		end
		if world.getBlockState(self.pos + vec(-self.collisionoffset.x, -0.1, self.collisionoffset.y)):hasCollision() then
			self.vel.y       = 0
			self.pos.y       = math.ceil(self.pos.y - 0.3)
			self.is_on_floor = true
		else
			self.is_on_floor = false
		end
		if world.getBlockState(self.pos + vec(self.collisionoffset.x, -0.1, -self.collisionoffset.y)):hasCollision() then
			self.vel.y       = 0
			self.pos.y       = math.ceil(self.pos.y - 0.3)
			self.is_on_floor = true
		else
			self.is_on_floor = false
		end
		if world.getBlockState(self.pos + vec(-self.collisionoffset.x, -0.1, -self.collisionoffset.y)):hasCollision() then
			self.vel.y       = 0
			self.pos.y       = math.ceil(self.pos.y - 0.3)
			self.is_on_floor = true
		else
			self.is_on_floor = false
		end
	end

	self.vel.x = self.vel.x * self.a_f
	self.vel.z = self.vel.z * self.a_f

	if self.curNode ~= nil and -self.pos.y + self.curNode.y >= 1 and self.is_on_floor == true and not self.engine then
		self.vel.y = self.vel.y + 0.35
		--self.pos.y = self.pos.y + 0.5
		self.is_jumping = true
	else
		self.is_jumping = false
	end
	return velocityToRotateTo
end

---Rotates the entity according to its velocity and the velocity added this tick
local function droneAI(self, targetPos)
	local startToMove = self.aiclock >= 17 and (self.pos - targetPos):length() > 0 and not self.mount
	self.ai           = self.engine and (self.double and "Air" or "Ground") or
		((self.try < 10) and
			((utils.isOnGround(self.targetEntity, 1) or self.targetEntity == nil) and "Ground" or "Air")
			or "Air"
		)
	--if self.try == 9 then self.pos = self.getTargetPos(self) end
	if self.engine then
		self.try = 0
	else
		if startToMove then
			self.aiclock = 0
			utils.pathfindingReset()
			for i = 0, self.fiterations do
				if #utils.Path == 0 then
					self.try = i
					if self.ai == "Air" then
						self.path = utils.pathfind(targetPos, self.pos, false)
					else
						self.path = utils.pathfind(targetPos, self.pos, self.try < 10 and true or false)
					end
					self.nextpathnode = 1
				else
					break
				end
			end
		end
	end
end

local function noBlock(self, blocksIDs)
	local yes = false
	for _, string in pairs(blocksIDs) do
		if self.block_inside.id:find(string) then
			yes = true
			break
		end
	end
	return yes
end

function dronezAPI.AITicker(instance)
	local opts = instance.options

	if opts.lastTap > 0 then
		opts.lastTap = opts.lastTap - 1
	elseif opts.lastTap == 0 then
		opts.tapcount = 0
		opts.lastTap = 0
	end

	local velocityToRotateTo, isPunched, isLove, inRain

	local looking              = (opts.targetEntity == player and host:isHost() and opts.targetEntity:isCrouching()) or
		opts.mount
	local rawTarget, hitEntity = utils.getLookTarget()
	local size                 = vec(opts.collisionoffset.x, opts.entitytoentitycolloff, opts.collisionoffset.x)
	local droneeyePos          = opts.AI and opts.group.head:partToWorldMatrix():apply() or
		opts.avatar and opts.neck:partToWorldMatrix():apply() or
		instance.mesh:partToWorldMatrix():apply() + vec(0, opts.vanillaObj:asEntity():getEyeHeight(), 0)

	isPunched, isLove          = droneInteraction(opts, size, looking, rawTarget, droneeyePos)
	opts.block_inside          = world.getBlockState(opts.pos + vec(0, -0.01, 0))
	local deafth               = noBlock(opts, deadly)

	if isLove then
		opts.is_loved = true
	elseif isPunched or deafth then
		opts.is_punched = true
	end
	if not (isLove or isPunched) and world:getTime() % 5 == 0 then
		opts.is_loved = false
		opts.is_punched = false
	end
	-->====================[ Formation ]====================<--
	local block, hitPos, side = player:getTargetedBlock(true, 3)
	--[[if block.id == "minecraft:grass_block" then
		log("You're looking at grass")
	end]]
	if player:isCrouching() and isLove and (opts.pos - player:getPos()):length() < 3 and opts.mount == false then
		if opts.index == 1 and C.Anchor.pochitaroot == nil then
			--log('gura')
			opts.mount = true
			instance.mesh.pochitaroot:moveTo(C.Anchor):pos(C.Anchor:getTruePivot() + C.Offset * 16)
		end
	elseif player:isCrouching() and player:getSwingTime() == 1 and opts.mount == true then
		if C.Anchor.pochitaroot ~= nil then
			if opts.index == 1 then
				opts.mount = false
				opts.vel   = vec(0, 0, 0)
				opts.s     = vec(0, 0, 0)
				opts.rot   = player:getBodyYaw()
				opts.pos   = hitPos
				C.Anchor.pochitaroot:moveTo(entityObjects[1].meshu):pos(entityObjects[1].meshu:getTruePivot())
			end
		end
	end

	if opts.is_punched then return end ------ hit stop

	local targetPos = opts.getTargetPos(opts)
	local targetRot = opts.getTargetRot(opts)
	targetPos       = targetPos or player:getPos() + vec(0, player:getBoundingBox().y, 0)
	targetRot       = targetRot or vec(0, 0, 0)
	local yaw, pitch
	local rotation  = 0

	local eyeDif    = (droneeyePos - targetPos):normalized()


	local eyeDif1         = (droneeyePos - rawTarget):normalized()
	pitch                 = looking and -math.deg(math.asin(eyeDif1.y)) or opts.engine and -player:getRot().x or
		-math.deg(math.asin(eyeDif.y))

	local targetEntityDis = opts.pos - targetPos
	local targetDis       = looking and droneeyePos - rawTarget or targetEntityDis

	opts.aiclock          = opts.aiclock + 1

	if opts.engine or opts.avatar then
		if opts.targetEntity ~= player then
			pitch = -math.deg(math.asin(eyeDif.y))
			yaw   = -(90 + math.deg(math.atan(eyeDif.z, eyeDif.x)) - opts.rot + 180) % 360 - 180
		else
			pitch = -player:getRot().x
			yaw = (-(player:getRot():sub(0, opts.rot)).y + 180) % 360 - 180
		end
	else
		pitch = -math.deg(math.asin(eyeDif.y))
		yaw   = (-(math.deg(math.atan2(eyeDif.z, eyeDif.x)) + 180) + opts.rot + 180) % 360 - 180
	end

	inRain             = world.isOpenSky(opts.pos) and not world.getBiome(opts.pos):isCold() and
		world.getRainGradient() > 0

	opts.is_underwater = (#opts.block_inside:getFluidTags() ~= 0)

	if opts.mount then
		opts.pos = player:getPos()
		opts.vel = player:getVelocity()
	else
		opts.posOld = opts.pos:copy()
		opts.lvel   = opts.vel:copy()
		opts.rotOld = opts.rot
	end
	-->====================[ Sync ]====================<--
	if (world:getTime() + opts.index * 20) % 20 == 0 then
		if opts.targetEntity.uuid then
			pings.dronezAPI_syncState(opts.index, opts.pos, opts.vel,
				client:uuidToIntArray(opts.targetEntity:getUUID()))
		else
			pings.dronezAPI_syncState(opts.index, opts.pos, opts.vel)
		end
	end
	-->====================[ Velocity & Rotation ]====================<--
	if opts.avatar then
		opts.is_preattack = utils.is_holding_sword
		opts.is_attacking = utils.is_attacking
		velocityToRotateTo = nil
		opts.rot = player:getBodyYaw()
		opts.posOld = opts.pos
		opts.pos = player:getPos()
		opts.vel = player:getVelocity()
		opts.is_on_floor = world.getBlockState(opts.pos + vec(0, -1.01, 0)):hasCollision()
		opts.is_jumping = host:isJumping()
	else
		if not opts.mount then
			for _, SecondEntity in pairs(Instances) do
				if (opts.pos - SecondEntity.options.pos):length() < 1 then
					local temp = (opts.pos - SecondEntity.options.pos) * 0.05
					opts.vel = opts.vel + temp.x_z
				end
			end
			if velocityToRotateTo == nil then
				if targetEntityDis:length() < 4 then
					rotation = (180 - math.deg(math.atan2(-targetDis.z, targetDis.x)) + 180) % 360 - 180
				else
					rotation = (utils.rotateEntityAccordingToVelocity((opts.vel)) + 180) % 360 - 180
				end
			else
				rotation = (utils.rotateEntityAccordingToVelocity(((velocityToRotateTo + opts.vel):normalize())) + 180) %
					360 - 180
			end
			-->====================[ Warp ]====================< --
			if targetEntityDis:length() > opts.warpThreshold then
				opts.pos = targetPos
			end

			velocityToRotateTo = droneMovement(opts, targetPos)
			droneAI(opts, targetPos)
			opts.rot = math.lerpAngle(rotation, opts.rot, 0.1) --self.rot = self.rot + self.str * self.loc_vel.z
		end
		-->====================[ Attack ]====================< --
		dronezAPI.targetFunctions.followNearbyEntities(opts)
		if opts.is_attacking then
			sounds['block.wart_block.break']
				:pos(player:getPos())
				:volume(0.5)
				:pitch(1)
				:play()
			sounds['entity.player.hurt']
				:pos(player:getPos())
				:volume(0.15)
				:pitch(2)
				:play()
			sounds['item.trident.return']
				:pos(player:getPos())
				:volume(0.1)
				:pitch(0.5)
				:play()
			local _, entity = pcall(utils.nearestEntity,
				opts.AI and droneeyePos or
				opts.group.body.root2.root3.saw:partToWorldMatrix():apply(), 1)
			utils.entityAttack(entity, vectors.angleToDir(opts.hrot) * 0.5, 2)
		end

		if opts.is_attacking then
			if (world:getTime() + opts.index * 20) % 10 == 0 then
				opts.roll = opts.roll + 180
			elseif (world:getTime() + opts.index * 20) % 5 == 0 then
				opts.roll = opts.roll - 180
			end
		else
			opts.roll = math.floor(opts.roll / 360 + 0.5) * 360
		end

		if not opts.AI then
			opts.vanillaObj:updateWalkingDistance(vec(opts.vel.x, 0, opts.vel.z):length())
		end
	end

	-->====================[ Swing ]====================< --
	opts.lhrot = opts.hrot * 1
	opts.lhvel = opts.hvel * 1
	opts.hrot  = vec(pitch, yaw)
	opts.hvel  = (opts.hrot - opts.lhrot + vec(180, 180)) % 360 - vec(180, 180)
	opts.hmom  = opts.hvel - opts.lhvel

	opts.hpvel = opts.hpvel * 0.8 - opts.hpos * 0.1 + opts.hmom
	opts.hpos  = opts.hpos + opts.hpvel
	table.insert(opts.hhis, 1, opts.hpos * 1)
	if #opts.hhis > 20 then table.remove(opts.hhis, 20) end

	opts.lbrot = opts.brot * 1
	opts.lbvel = opts.bvel * 1
	opts.brot = rotation
	opts.bvel = (opts.brot - opts.lbrot + 180) % 360 - 180
	opts.bmom = opts.bvel - opts.lbvel

	opts.bpvel = opts.bpvel * 0.8 - opts.bpos * 0.1 + opts.bmom
	opts.bpos = opts.bpos + opts.bpvel
	table.insert(opts.bhis, 1, opts.bpos * 1)
	if #opts.bhis > 20 then table.remove(opts.bhis, 20) end
	-->====================[ SPRING ]====================<--
	if not opts.mount then
		local vecRot           = opts.avatar and opts.rot or 270 + opts.rot
		local patwobble        = (isLove or opts.is_punched) and -player:getLookDir() or vec(0, 0, 0)
		local vel, pos         = opts.velS, opts.posS
		-- Gets the directional velocity rotated to player-space
		local relativeVelocity = vectors.rotateAroundAxis(vecRot, (-opts.vel + patwobble) * vec(1, -1, 1),
			vec(0, 1, 0))

		opts.velS              = vel
		opts.posS              = pos
		opts.old               = opts.new
		opts.new               = mat
		-- Update private vars
		opts.loc_lvel          = opts.loc_vel
		opts.loc_vel           = relativeVelocity

		opts.ls                = opts.s:copy()
		opts.s                 = opts.s + opts.sv
		opts.sv                = opts.sv * 0.4 + vec(opts.loc_vel.x - opts.loc_lvel.x,
			opts.lvel.y - opts.vel.y, opts.loc_vel.z - opts.loc_lvel.z) * 2 - opts.s * 0.9

		opts.ldt               = opts.dt
		opts.dt                = opts.dt + opts.loc_vel.z
	elseif opts.mount then
		opts.posOld = C.Anchor:partToWorldMatrix():apply()
		opts.pos    = C.Anchor:partToWorldMatrix():apply()
		opts.lvel   = vec(0, 0, 0)
		opts.vel    = vec(0, 0, 0)
		opts.ls     = vec(0, 0, 0)
		opts.s      = vec(0, 0, 0)

		opts.hrot   = vec(0, 0)
	end
	-->====================[ EMOTE ]====================<--
	opts.blink_timer = opts.blink_timer - 1
	if opts.blink_timer < 0 then
		opts.blink_timer = math.lerp(1 * 20, 3 * 20, math.random())
	end
	opts.ohhot = noBlock(opts, hotty)

	opts.targetLight = math.map(world.getLightLevel(opts.pos + vec(0, 1, 0)), 0, 15, (client:hasShaderPack() and .4 or 0),
		(client:hasShaderPack() and .6 or 0.8)) * opts.wetness

	instance.mesh:setSecondaryRenderType(opts.is_punched and "LINES_STRIP" or opts.is_loved and "GLINT" or "NONE")

	if opts.vanillaObj == nil then
		opts.extraData = {
			['minecraft:armor_stand'] = {
				function()
					return { opts.ohhot }
				end,
				function()
					return {
						Fire      = opts.ohhot and 100 or 0,
						Invisible = true
					}
				end
			}
		}
		opts.vanillaObj = instance.mesh:newPart '':newEntity '' --:setNbt("minecraft:lightning_bolt", "{}")
		pcall(opts.vanillaObj.setNbt, opts.vanillaObj, 'minecraft:armor_stand', '{}')
		updateEntity(opts, opts.vanillaObj, 'minecraft:armor_stand')
	end
	updateEntity(opts, opts.vanillaObj, 'minecraft:armor_stand')
	if inRain then
		opts.wetness = opts.wetness - 0.005
		if opts.wetness <= 0.5 then opts.wetness = 0.5 end
	elseif opts.is_underwater then
		if opts.block_inside.id:find("lava") or world.getBlockState(opts.pos).id:find("fire") then
			opts.hotness = 0.5
		else
			opts.wetness = 0.5
		end
	end
	if opts.wetness >= 1 then opts.wetness = 1 end
	if opts.wetness ~= 1 and not (opts.is_underwater or inRain) then
		opts.wetness = opts.wetness + 0.005
		if world:getTime() % 20 then
			for _ = 1, 3 do
				particles:newParticle("minecraft:falling_dripstone_water",
					opts.pos.x + math.random() - 0.7,
					opts.pos.y + math.random(), opts.pos.z + math.random() - 0.7, math.random(-1, 1),
					math.random(-1, 1), math.random(-1, 1))
			end
		end
	end
	if opts.hotness >= 1 then opts.hotness = 1 end
	if opts.hotness ~= 1 then
		opts.hotness = opts.hotness + 0.005
		if world:getTime() % 20 then
			for _ = 1, 3 do
				particles:newParticle("minecraft:falling_dripstone_lava",
					opts.pos.x + math.random() - 0.7,
					opts.pos.y + math.random(), opts.pos.z + math.random() - 0.7, math.random(-1, 1),
					math.random(-1, 1), math.random(-1, 1))
			end
		end
	end
	if isLove then
		sounds:playSound("minecraft:entity.cat.beg_for_food", droneeyePos, 1, 1)
		for _ = 1, 4 do
			particles:newParticle("minecraft:heart", droneeyePos.x + math.random() - 0.7,
				droneeyePos.y + math.random(), droneeyePos.z + math.random() - 0.7, math.random(-1, 1),
				math.random(-1, 1), math.random(-1, 1))
		end
	elseif isPunched then
		sounds:playSound("minecraft:entity.armor_stand.break", opts.pos, 0.5, 1.2)
		sounds:playSound("minecraft:entity.wolf.hurt", opts.pos, 1, 1)
		for _ = 1, 1 do
			particles['minecraft:explosion']:lifetime(5):pos(opts.pos + vec(0, 1, 0)):spawn()
		end
	end
	return opts
end

function dronezAPI.defaultTicker(instance)
	instance.posOld = instance.pos
	instance.rotOld = instance.rot
	instance.pos = instance.pos
	instance.rot = instance.rot
end

-- 呼吸のリズム（イン・アウト）を計算する関数
local function get_breathing_value(time, duration)
	-- duration: 1呼吸の秒数（例: 4.0秒）
	-- サイン波を使って 0.0（吐ききった）から 1.0（吸いきった）の値を返す
	local frequency = (2 * math.pi) / duration
	local raw_sin = math.sin(time * frequency)
	-- -1～1の範囲を0～1に変換
	return (raw_sin + 1) / 2
end
local function get_breathing_value2(time, duration)
	-- duration: 1呼吸の秒数（例: 4.0秒）
	-- サイン波を使って 0.0（吐ききった）から 1.0（吸いきった）の値を返す
	local frequency = (2 * math.pi) / duration
	local raw_sin = math.cos(time * frequency)
	-- -1～1の範囲を0～1に変換
	return (raw_sin + 1) / 2
end


-->====================[ AI render ]====================<----MADE BY @GNamimates EDIT BY @Muscat
local lastDelta = 0
function dronezAPI.AIRenderer(instance, dt)
	local opts = instance.options
	if not player:isLoaded() then return end
	--if opts.is_punched then return end

	local dtt = dt - lastDelta
	if dtt < 0 then
		dtt = dtt + 1
	end
	dtt       = dtt / 20
	lastDelta = dt

	local function animate(type, part, addon)
		local data = addon or vec(0, 0, 0)
		if type == "rot" then
			return part:setRot(math.lerpAngle(part:getRot(), data, dt * 0.25))
		elseif type == "pos" then
			return part:setPos(math.lerp(part:getPos(), data, 0.1))
		elseif type == "scl" then
			return part:setScale(math.lerp(part:getScale(), data, dt * 0.25))
		end
	end

	local true_blade     = opts.is_attacking and 1 or 0
	local breathe        = get_breathing_value(client:getSystemTime() / 100, 60) / 5
	local breathe2       = get_breathing_value2(client:getSystemTime() / 100, 3) / 10
	local breathe3       = get_breathing_value(client:getSystemTime() / 100, 1) / 5 * true_blade
	local breathe4       = get_breathing_value2(client:getSystemTime() / 100 + 300, 1) / 10 * true_blade
	local tpos           = math.lerp(opts.posOld, opts.pos, dt)
	local true_vel       = math.lerp(opts.lvel, opts.vel, dt)
	local true_vel2      = math.lerp(opts.loc_lvel, opts.loc_vel, dt)
	local true_sus       = math.lerp(opts.ls, opts.s, dt)
	local speed          = math.clamp(true_vel2.z * 25, -90, 90)
	--local speed2         = math.clamp(dtt * (8 + math.abs(speed * 2)), 0, 0.5)
	local duck           = math.clamp(true_sus.y * 16, 0, 15)
	local true_rot       = math.lerpAngle(opts.rotOld, opts.rot, dt)
	local headrot        = math.lerp(opts.lhrot, opts.hrot, dt)
	local fall           = math.clamp(math.min(opts.velS.y - math.abs(opts.velS.z * 0.5), 0), -1, 0) * 90
	local true_dist_trav = math.lerp(opts.ldt, opts.dt, dt)
	local sinwave        = math.sin(true_dist_trav * 5) * math.min((opts.loc_vel.z * 3), 1)
	local flap           = -sinwave * (45 + vec(true_vel.x, 0, true_vel.z):length() * 45) + breathe * 90
	local attack         = -math.abs(math.atan(opts.roll * true_blade))

	--local pH, pB         = opts.hhis[3] and math.lerp(opts.hhis[3], opts.hhis[2], dt) or vec(0, 0),
	--	opts.bhis[3] and math.lerp(opts.bhis[3], opts.bhis[2], dt) or 0
	--local force_solid    = noBlock(opts, not1x1Block)
	--local matt           = math.lerp(opts.old, opts.new, dt)
	--matt.c1              = vectors.vec4(matt.c1.x + pH.y / 200, matt.c1.y, pH.y / 50, matt.c1.w)
	--offsetPivot(matt, opts.neck.hed.hair:getPivot())
	--opts.neck.hed.hair:matrix(matt)--:scale(1, 1 - true_sus.y, 1)
	instance.mesh:setVisible(world:getTime() > 10 and true or false):pos(tpos * 16)
		:scale(vec(1, 1 - breathe2, 1) - vec(0, -true_sus.y, 0) * 0.25)
	if opts.AI then
		local force_solid = noBlock(opts, not1x1Block)
		opts.lerpLight = math.lerp(opts.lerpLight, opts.targetLight, dt / 3)
		instance.mesh:setPrimaryColor((opts.is_punched or opts.ohhot) and vec(1, 0.5, 0.5) or opts.lerpLight)
			:setSecondaryColor(1)


		if opts.engine then
			opts.vanillaObj:rot(0, -true_rot, 0)
				:scale(2)
		elseif opts.avatar then
			opts.vanillaObj:rot(0, 180 + true_rot, 0)
				:scale(2)
		else
			opts.vanillaObj:rot(0, -270 + true_rot, 0)
				:scale(2)
		end
		--[[instance.mesh.monkey:pos(math.lerp(instance.mesh.monkey:getTruePos(), vec(0, (force_solid and -10 or 0), 0),
			0.1))]]
		animate("rot", instance.mesh,
			vec((true_vel.y - opts.g) * -opts.velS.z * 90 + math.deg(-true_sus.z) * 0.3 + speed * 5,
				270 - true_rot,
				math.deg(-true_sus.x)))
		animate("pos", opts.group.body.root2,
			vec(0,
				math.abs(math.sin(true_dist_trav * 2) * math.min((opts.loc_vel.z * 3))) * 10 +
				((force_solid and not opts.mount) and -10 or 0),
				attack * 8))
		-->====================[ Body parts ]====================<--
		--opts.head:rot(vec(headrot.x * 0.5, (headrot.y + pH.y) * 0.33, 0))
		local blinky = opts.is_loved and 0.3 or opts.blink_timer < 4 and 0 or 1
		opts.group.head:setScale(1, blinky)
		opts.group.body.root2.root3.t:scale(vec(1, 1 + (breathe2 * 3), 1))
		opts.group.body.root2.root3.saw:rot(breathe4 * 90, breathe3 * 30)
		opts.group.body.root2.root3.saw.saw2:scale(vec(1, 1 + (breathe3), 1 - (breathe4)))

		for _, value in pairs(opts.parts) do
			local v = value.intensity
			if opts.hhis[value.delay + 2] then
				if value.physics_type == "head" then
					local p = vec(0, 0)
					if value.type == "top" then
						value.group:setRot(vec(p.x, p.y, 0) * v)
					elseif value.type == "front" then
						value.group:setRot(vec(p.x, 0, -p.y) * v)
					elseif value.type == "side" then
						value.group:setRot(vec(p.x, 0, -p.y) * v)
					elseif value.type == "back" then
						value.group:setRot(vec(-math.max(headrot.x * 0.75 + speed + p.x * 0.25, 0) -
							speed * 135, 0, p.y * 0.25) * v)
					else
						--animate("rot", value.group, vec(headrot.x * 0.5, (headrot.y + p.y) * 0.33, 0))
					end
				else
					local p = math.lerp(opts.hhis[2], opts.hhis[1], dt).y * 0.1
					if value.physics_type == "am" then
						animate("rot", value.group,
							vec((-p * v * 0.5 + duck * -8), 0, -fall * v) +
							vec(true_blade * v * 90 + attack * 20,
								flap * v,
								(-flap + 22.5) * v))
					elseif value.physics_type == "h" then
						animate("rot", value.group, vec(0, 0, 0))
					elseif value.physics_type == "body" then
						if value.type == "side" then
							value.group:setRot(-p * v + speed * -90, 0, fall * v + p * v)
						elseif value.type == "back" then
							value.group:setRot(math.max(duck * 4 - speed, 0) * v - p * v * 0.25 -
								math.clamp(speed * 90, 0, 90) + fall, 0, -p * v * 0.25)
						else
							animate("rot", value.group,
								vec(duck * 4, -p * v * 0.5, 0))
						end
					elseif value.physics_type == "lg" then
						animate("rot", value.group, vec(attack * 20, -p * v * 0.5, 0)
							+ vec(0, flap * v, (-flap + 5) * v))
						--effect(value.group)
					elseif value.physics_type == "tail" then
						local svel = math.clamp((opts.vel * matrices.rotation3(0, -opts.rot, 0)).x, -0.3, 0.3) * 100
						local timewag = vec(0, (client.getSystemTime() / 100), 0)
						local strength = vec(opts.vel:length() * 3, opts.vel:length() * 33, 0)
						for i, v2 in pairs(opts.tailParts) do
							local k = math.floor((i - 1) / #opts.tailParts * 1) + 1
							local l = math.cos((k - 1) * math.pi / 2) + math.sin((k - 1) * math.pi / 2)
							local wag = vec(math.sin((world:getTime() + dt) / 5), math.cos((world:getTime() + dt) / 10),
									0) *
								vec(l * 10, 10, 0) --* opts.vel:length()
							v2:rot(vec(0, -p - svel, 0) +
								(timewag - i):applyFunc(math.cos) * strength + wag)
						end
					end
				end
			end
		end
	else
		opts.vanillaObj:setHeadRotation(-vec(headrot.x, headrot.y))
		animate("rot", instance.mesh,
			vec((true_vel.y - opts.g) * opts.loc_vel.z * 90 - math.deg(-true_sus.z) * 0.3 - speed * 5,
				90 - true_rot + headrot.y * 0.33,
				math.deg(-true_sus.x)
			)
		)
	end
end

-->====================[ dronezAPI ]====================<--MADE BY @piratesee EDIT BY @Muscat
local DefaultConfettoOptions = {}
local function mapmodel(partsTable, currentPart)
	if type(currentPart) == 'table' then
		partsTable = currentPart
	else
		local n, i = currentPart:getName():match("^(.-)(-?%d*)$")
		i = tonumber(i) or 1
		while currentPart do
			table.insert(partsTable, currentPart)
			i = i + 1
			currentPart = currentPart[n .. i]
		end
	end
end
function DefaultConfettoOptions:new(meshInstance, pos, AI, avatar) --Courtesy of @piratesee and @SOOMUCHLAG and @GNamimates and @4p5 on discord
	self                                                                           = setmetatable({},
		DefaultConfettoOptions)
	self.lifetime                                                                  = 20
	self.avatar                                                                    = avatar
	self.meshu                                                                     = meshInstance
	--instantiate
	entityObjects[entityObjectsCount + 1]                                          = self
	entityObjectsCount                                                             = entityObjectsCount + 1
	--check
	--init vars
	self.pos, self.posOld                                                          = pos, pos
	self.rot, self.rotOld                                                          = 0, 0
	self.lvel, self.vel --[[                   Velocity ]]                         = vec(0, 0, 0), vec(0, 0, 0)
	self.index                                                                     = entityObjectsCount

	self.targetLight                                                               = 1
	self.lerpLight                                                                 = 0
	local MapperObj                                                                = utils.ModelMapper(meshInstance)

	self.shift                                                                     = false
	--stats
	self.topSpeed                                                                  = 0.6 -- maximum speed in blocks/tick entity can reach
	self.acceleration                                                              = 0.06 -- velocity change per tick
	self.brakeMultiplier                                                           = 0.5 -- velocity multiplier when stopping
	self.stopThreshold                                                             = 1.5 -- maximum distance per axis to target to consider close enough and stop
	self.punchImpulse                                                              = 0.25 -- force added when punched
	self.warpThreshold                                                             = 16 -- threshold to be far enough to warp closer to target. set to math.huge to effectively disable
	self.warpDistance                                                              = 5 -- distance from target to warp to
	self.targetEntity                                                              = nil
	-->========================================[ Suspension ]=========================================<--
	self.ls, self.s --[[                    Suspension ]]                          = vec(0, 0, 0),
		vec(0, 0, 0)                                                                           -- locked
	self.sv --[[                    Suspension Velocity ]]                         = vec(0, 0, 0) -- locked
	-->========================================[ Physics ]=========================================<--
	self.g --[[                 gravity used by the car ]]                         = -0.07
	self.wjg --[[                        normal gravity ]]                         = 0.2
	self.ng --[[                         normal gravity ]]                         = -0.07
	self.jg --[[                           jump gravity ]]                         = -0.03
	--self.wheels                                                                    = {} --(automatic)
	self.loc_vel                                                                   = vec(0, 0, 0)
	self.loc_lvel                                                                  = vec(0, 0, 0)
	self.velS                                                                      = vec3:copy()
	self.posS                                                                      = vec3:copy()
	self.old                                                                       = mat4:copy()
	self.new                                                                       = mat4:copy()
	-->========================================[ Statistics ]=========================================<--
	self.is_fly --[[                             ]]                                = false -- locked
	self.is_underwater --[[                             ]]                         = false -- locked
	self.is_on_floor --[[               is on the floor ]]                         = false -- locked

	self.block_inside --[[                              ]]                         = nil -- locked
	self.is_jumping --[[                                ]]                         = false -- locked
	self.is_attacking --[[                                ]]                       = false -- locked
	self.is_preattack --[[                                ]]                       = false -- locked
	self.is_punched --[[                                ]]                         = false -- locked
	self.is_loved --[[                                ]]                           = false -- locked

	self.ldt, self.dt --[[                 distance traveled ]]                    = 0, 0
	self.vanillaObj                                                                = nil
	self.extraVars                                                                 = {}
	self.extraData                                                                 = {}

	self.AI                                                                        = AI
	self.wetness                                                                   = 1
	self.hotness                                                                   = 1
	self.shake                                                                     = 0
	self.blink_timer                                                               = 0

	self.lhrot, self.hrot                                                          = vec(0, 0), vec(0, 0)
	self.hhis                                                                      = {}
	self.bhis                                                                      = {}

	self.roll                                                                      = 0

	self.ai                                                                        = 'Air'
	self.bob                                                                       = 0
	self.path                                                                      = {}

	self.hvel, self.lhvel, self.hmom, self.hpos, self.hpvel                        = vec(0, 0), vec(0, 0), vec(0, 0),
		vec(0, 0), vec(0, 0)
	self.lbrot, self.brot, self.bvel, self.lbvel, self.bmom, self.bpos, self.bpvel = 0, 0, 0, 0, 0, 0, 0

	self.nextpathnode                                                              = 1
	self.aiclock                                                                   = 0

	self.collisionoffset                                                           = vec(0.47, 0.47)
	self.entitytoentitycolloff                                                     = 0.25
	self.curNode                                                                   = nil
	self.fiterations                                                               = 15
	self.try                                                                       = 0
	self.maxVelocity                                                               = 5

	self.tapcount                                                                  = 0
	self.lastTap                                                                   = 0
	self.double                                                                    = false
	self.extraVars                                                                 = {}
	self.extraData                                                                 = {}

	if AI then -->====================[ BODY PARTS ]====================<--
		self.group     = {
			head = MapperObj["hed"],
			body = MapperObj["pochitaroot"],
			RA = MapperObj["rightarm"],
			LA = MapperObj["leftarm"],
			RL = MapperObj["rightleg"],
			LL = MapperObj["leftleg"],
			tail = MapperObj["tail"],
		}
		self.state     = nil
		self.mount     = false
		self.parts     = {
			{ group = self.group.head, physics_type = "head", intensity = 1,  delay = 1 },
			{ group = self.group.body, physics_type = "body", intensity = -1, delay = 1 },
			{ group = self.group.RA,   physics_type = "am",   intensity = 1,  delay = 1 },
			{ group = self.group.LA,   physics_type = "am",   intensity = -1, delay = 1 },

			{ group = self.group.RL,   physics_type = "lg",   intensity = 1,  delay = 1 },
			{ group = self.group.LL,   physics_type = "lg",   intensity = -1, delay = 1 },

			{ group = self.group.tail, physics_type = "tail", intensity = 1,  delay = 1 },
		}
		self.tailParts = {}
		mapmodel(self.tailParts, MapperObj["tail"])
	elseif avatar then
		self.neck = MapperObj[C.parts.head]
		self.body = MapperObj[C.parts.body]
	end

	self.getTargetPos = dronezAPI.targetFunctions.followEntity
	self.getTargetRot = dronezAPI.targetFunctions.lookAround
	function self:setTargetPosFunction(arg)
		self.getTargetPos = arg
		return self
	end

	function self:setTargetRotFunction(arg)
		self.getTargetRot = arg
		return self
	end

	self.init     = dronezAPI.defaultTicker
	self.ticker   = dronezAPI.defaultTicker
	self.renderer = dronezAPI.defaultRenderer
	return self
end

local Confetto = {}
Confetto.__index = Confetto
function Confetto:new(mesh, pos, vel, avatar, options)
	return setmetatable({
		mesh          = mesh,
		avatar        = avatar,
		pos           = pos,
		posOld        = pos,
		vel           = vel,
		lvel          = vel,
		lifetime      = options.lifetime,
		mirage_trails = {},
		rot           = options.rot,
		rotOld        = options.rot,
		options       = options
	}, Confetto)
end

function dronezAPI.registerMesh(name, mesh, lifetime)
	Particles[name] = { mesh = mesh, lifetime = lifetime or 20 }
	mesh:setVisible(false)
end

function dronezAPI.newDroneUnchecked(name, AI, pos, vel, avatar, options)
	local ptcl = Particles[name]
	local meshInstance
	if ptcl.mesh ~= nil then
		if avatar then
			meshInstance = ptcl.mesh
		else
			local copiedModel = utils.copyModel(ptcl.mesh)
			modelinstances:addChild(copiedModel)
			meshInstance = copiedModel
		end
	end
	meshInstance:setPrimaryRenderType("CUTOUT_EMISSIVE_SOLID"):setSecondaryRenderType("EMISSIVE"):setVisible(true)
	options.lifetime = options.lifetime or ptcl.lifetime
	setmetatable(options, { __index = DefaultConfettoOptions:new(meshInstance, pos, AI, avatar) })
	local particle = Confetto:new(meshInstance, pos, vel, avatar, options)
	options.init(particle)
	Instances[client.intUUIDToString(client.generateUUID())] = particle
	return particle
end

function dronezAPI.newDrone(name, AI, pos, vel, avatar, options)
	vel = vel or vec(0, 0, 0)
	options = options or {}
	return dronezAPI.newDroneUnchecked(name, AI, pos, vel, avatar, options)
end

-->====================[ Networking ]====================<--
-- ping stuff
function pings.dronezAPI_syncState(index, pos, velocity, a, b, c, d)
	-- sync most information
	if not player:isLoaded() then return end
	if not host:isHost() and player:getPermissionLevel() >= 4 then
		entityObjects[index].pos = pos + velocity
		entityObjects[index].vel = velocity
		if a then
			entityObjects[index].targetEntity = world.getEntity(client:intUUIDToString(a, b, c, d))
		end
	end
end

function pings.dronezAPI_syncEntity(index, a, b, c, d)
	-- just sync entity
	entityObjects[index].targetEntity = world.getEntity(client:intUUIDToString(a, b, c, d))
	entityObjects[index].aquireCounter = 0
end

function pings.GNRCcarHandbreak(index, bool)
	entityObjects[index].is_handbreak = bool
end

function pings.dronezAPI_syncDelete(index)
	if index ~= nil and Instances[index] ~= nil then
		modelinstances:removeChild(Instances[index].mesh)
		Instances[index].mesh:remove()
		for j, thing in pairs(Instances[index]) do
			thing = nil
		end
		--table.remove(Instances, index)
		if entityObjectsCount > 1 then
			entityObjectsCount = entityObjectsCount - 1
		end
	end
end

function pings.GetIndexLook()
	local AABBtable = {}
	for _, v in pairs(Instances) do
		local tempvec = vec(v.collisionoffset.x, 0, v.collisionoffset.y) + v.pos
		local tempvec2 = vec(-v.collisionoffset.x, 2, -v.collisionoffset.y) + v.pos
		table.insert(AABBtable, { tempvec, tempvec2 })
	end
	local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
	local eyeEnd = eyePos + (player:getLookDir() * 40)
	local aabb, hitPos, side, aabbHitIndex = raycast:aabb(eyePos, eyeEnd, AABBtable)
	if aabbHitIndex ~= nil and Instances[aabbHitIndex] ~= nil then
		--Instances[aabbHitIndex].mesh:remove()
		return aabbHitIndex
	end
end

dronezAPI.targetFunctions = {}
-- follows and looks at the targetEntity. If targeting player, look in their direction instead
function dronezAPI.targetFunctions.followEntity(entityObj)
	entityObj.localOffset = entityObj.localOffset or vec(0, 1, 0) -- offset in look direction
	entityObj.offsetRot = entityObj.offsetRot or vec(0, 1, 0)  -- offset rot
	-- fallback target
	if not entityObj.targetEntity then
		entityObj.targetEntity = player
	end
	-- check if the target is loaded to avoid uninit error
	if entityObj.targetEntity:isLoaded() then
		-- return target pos as 1 block above their hitbox, and the rotation
		return entityObj.targetEntity:getPos() + ((entityObj.targetEntity ~= player) and vec(0, 0, 0) or
			(vec(0, entityObj.targetEntity:getBoundingBox().y, 0) +
				(entityObj.ai == "Air" and
					vectors.rotateAroundAxis(math.deg(math.atan2(entityObj.targetEntity:getLookDir().x, entityObj.targetEntity:getLookDir().z)),
						entityObj.localOffset, vec(0, 1, 0)) or 0)))
	end
end

function dronezAPI.targetFunctions.followNearbyEntities(entityObj)
	entityObj.localOffset = entityObj.localOffset or vec(0, 1, 0) -- offset in look direction
	entityObj.aquireWaitTime = entityObj.aquireWaitTime or 600
	entityObj.aquireCounter = entityObj.aquireCounter or 0     -- counter until aquiring

	if not entityObj.engine then
		-- add keybind
		if not entityObj.aquireKeybind then
			if C.Input.Detect:isPressed() then
				local hitPos, entity = utils.getLookTarget()
				entityObj.targetEntity = entity
				--entityTimer = 0
				if entity then
					pings.dronezAPI_syncEntity(entityObj.index, client:uuidToIntArray(entity:getUUID()))
				else
					pings.dronezAPI_syncEntity(entityObj.index, client:uuidToIntArray(player:getUUID()))
				end
			end
		end
		-- increment counter
		entityObj.aquireCounter = entityObj.aquireCounter + 1
		-- if counter finished
		--log(entityObj.aquireCounter)
		if entityObj.aquireCounter > entityObj.aquireWaitTime then
			if entityObj.targetEntity == player then
				-- stupid amount of raycasts, host only
				if host:isHost() then
					local entity = utils.nearestEntity(entityObj.pos, 32)
					-- found entity
					if entity and C.noOwner(entity) then
						entityObj.targetEntity = entity
						entityObj.aquireCounter = 0
						-- sync
						pings.dronezAPI_syncEntity(entityObj.index, client:uuidToIntArray(entity:getUUID()))
					end
				end
			else
				-- if already following an entity, go back to player
				entityObj.targetEntity = player
				entityObj.aquireCounter = 0
			end
		end
		-- fallback target
		if not entityObj.targetEntity then
			entityObj.targetEntity = player
		end
	end
	-- check if the target is loaded to avoid uninit error
	if entityObj.targetEntity:isLoaded() then
		-- return target pos as 1 block above their hitbox, and the rotation
		return entityObj.targetEntity:getPos() + ((entityObj.targetEntity ~= player) and vec(0, 0, 0) or
			(vec(0, entityObj.targetEntity:getBoundingBox().y, 0) +
				(entityObj.ai == "Air" and
					vectors.rotateAroundAxis(math.deg(math.atan2(entityObj.targetEntity:getLookDir().x, entityObj.targetEntity:getLookDir().z)),
						entityObj.localOffset, vec(0, 1, 0)) or 0)))
	end
end

-- looks at entity
function dronezAPI.targetFunctions.lookAt(entityObj)
	entityObj.offsetRot = entityObj.offsetRot or vec(0, 0, 0) -- offset rot
	if entityObj.targetEntity:isLoaded() then
		return vec(0, math.deg(math.atan2(entityObj.pos.x - entityObj.targetEntity:getPos().x,
			entityObj.pos.z - entityObj.targetEntity:getPos().z)) + 180, 0) + entityObj.offsetRot
	end
end

-- looks in the direction that the entity is looking in
function dronezAPI.targetFunctions.lookWith(entityObj)
	entityObj.offsetRot = entityObj.offsetRot or vec(0, 0, 0) -- offset rot
	if entityObj.targetEntity:isLoaded() then
		return vec(0, math.deg(math.atan2(entityObj.targetEntity:getLookDir().x, entityObj.targetEntity:getLookDir().z)),
			0) + entityObj.offsetRot
	end
end

-- uses lookWith when host player, or lookAt for others
function dronezAPI.targetFunctions.lookAround(entityObj)
	if entityObj.targetEntity:isLoaded() then
		if entityObj.targetEntity == player then
			return dronezAPI.targetFunctions.lookWith(entityObj)
		else
			return dronezAPI.targetFunctions.lookAt(entityObj)
		end
	end
end

events.ON_PLAY_SOUND:register(function(id, pos, volume, pitch, loop, category, path)
	for key, instance in pairs(Instances) do
		local opts = instance.options

		if id == "minecraft:entity.generic.explode" and (pos - opts.pos):length() < 4 then
			opts.shake = math.max(opts.shake, 90 / ((pos - opts.pos):length()))
			opts.is_punched = true
			opts.vel = opts.vel + (opts.pos - pos):normalized()
			opts.vel.y = opts.vel.y + 0.25
		end
	end
end)
function events.tick()
	for key, instance in pairs(Instances) do
		instance.options.ticker(instance)
		instance.lifetime = instance.lifetime - 1
		if instance.lifetime <= 0 then
			for id, _ in pairs(instance.mirage_trails) do
				if instance.mirage_trails[id] then
					instance.mirage_trails[id].trail:delete()
					instance.mirage_trails[id] = nil
				end
			end
			modelinstances:removeChild(instance.mesh)
			pings.dronezAPI_syncDelete(key)
			Instances[key] = nil
		end
	end
end

function events.render(dt)
	for _, instance in pairs(Instances) do
		instance.options.renderer(instance, dt)
	end
end

return dronezAPI
