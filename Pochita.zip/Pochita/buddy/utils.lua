local C     = require("buddy.config")
local utils = {
  --[[is_crouching       = false,
  is_holding_sword   = false,
  is_holding_tool    = false,
  is_gun             = false,
  hold               = false,
  is_forward         = false,
  is_back            = false,
  is_rise            = false,
  is_hurt            = false,
  is_dead            = false,
  just_rise          = false,
  is_fall            = false,
  is_land            = false,
  is_right           = false,
  is_left            = false,
  is_sitting         = false,
  is_in_water        = false,
  is_swim            = false,
  is_riptide         = false,
  is_charge_tridentR = false,
  is_on_ground       = false,
  is_walking         = false,
  is_sprinting       = false,
  is_standing        = false,
  BC                 = false,
  is_attacking       = false,]]
  Path = {},
}
--[[local cooldown  = 0
local oldhealth = 0
local function notFalling()
  return client:getViewer():isFlying()
      or utils.is_on_ground
      or utils.is_in_water
      or utils.is_climbing
      or player:getVelocity()[2] > 0
      or player:getPose() == "FALL_FLYING"
end

events.ON_PLAY_SOUND:register(function(id, pos)
  if player:isLoaded() and pos:copy():sub(player:getPos()):length() <= 0.5 then
    if id:find("bettercombat") or id:find("simplyswords") then
      utils.BC = true
    end
  end
end)

events.TICK:register(function()
  local pose = player:getPose()
  local health = player:getHealth() + player:getAbsorptionAmount()
  if oldhealth > health and player:getNbt().HurtTime == 9 then
    utils.is_hurt = true
  elseif health == 0 then
    utils.is_dead = true
  else
    utils.is_dead = false
  end
  oldhealth = health
  local wvel = math.max(-0.3, math.min(0.3, player:getVelocity():dot((player:getLookDir().x_z):normalize())))
  local svel = math.max(-0.3, math.min(0.3, (player:getVelocity() * matrices.rotation3(0, player:getRot().y, 0)).x))
  ------ walking detection ------
  utils.is_forward = wvel > 0
  utils.is_back = wvel < 0
  utils.is_right = svel > 0
  utils.is_left = svel < 0
  utils.is_walking = utils.is_forward or utils.is_back or utils.is_left or utils.is_right
  ------ battle mode detection ------
  utils.is_holding_sword = player:getHeldItem().id:find("trident") or player:getHeldItem().id:find("sword") or
      player:getHeldItem().id:find("cataclysm") or
      player:getHeldItem().id:find("simplyswords") or player:getHeldItem().id:find("slashblade")
  ------ minning mode detection ------
  utils.is_holding_tool = player:getHeldItem().id:find("hoe") or player:getHeldItem().id:find("shovel") or
      player:getHeldItem().id:find("axe") or player:getHeldItem().id:find("pick")
  ------ FPS mode detection ------
  utils.is_gun = player:getHeldItem().id:find("modern_kinetic_gun")
  ------ inwater detection ------
  utils.is_in_water = player:isInWater() or player:isInLava()
  -- returns y velocity ------
  utils.is_rise = player:getVelocity()[2] > 0
  local vehicle = player:getVehicle()
  local sithorse = vehicle ~= "minecraft:horse" or vehicle ~= "minecraft:mule" or vehicle ~= "minecraft:mule" or
      vehicle ~= "minecraft:donkey"
  local sitting = vehicle ~= nil or pose == "SITTING"
  local playerGround = world.getBlockState(player:getPos():add(0, -.1, 0))
  local vehicleGround = sitting and world.getBlockState(vehicle:getPos():add(0, -.1, 0))
  ------ grounding detection ------
  utils.is_on_ground = playerGround:isSolidBlock() or player:isOnGround()
      or (sitting and vehicleGround:isSolidBlock() or sitting and vehicle:isOnGround())
  ------ sitting detection --------
  utils.is_sitting = sitting
  utils.is_fall = (not utils.isOnGround(player, 3)) and not notFalling()
  ------ swim detection ------
  utils.is_swim = pose == "SWIMMING"
  ------ trident detection ------
  utils.is_riptide = player:riptideSpinning()
  utils.is_charge_tridentR = player:getHeldItem(player:isLeftHanded()).id == "minecraft:trident" and
      player:getHeldItem(player:isLeftHanded()):getUseAction() and player:isUsingItem() and
      (vanilla_model.RIGHT_ARM:getOriginRot().x > 90 or vanilla_model.LEFT_ARM:getOriginRot().x > 90)
  ------ handing detection ------
  utils.hold = utils.is_holding_sword or utils.is_holding_tool or utils.is_gun
  ------ sprinting detection ------
  utils.is_sprinting = player:getVelocity().xz:length() > 0.25 and utils.is_on_ground
  ------ sneak detection ------
  utils.is_crouching = player:isCrouching()
  ------ land detection ------
  utils.is_land = utils.isOnGround(player, 3)
  ------ stand detection ------
  utils.is_standing = player:getVelocity().xz:length() < .01 and utils.is_on_ground and not utils.is_sitting
  ------ attacking detection ------
  if utils.is_holding_sword then
    if player:getSwingTime() == 1 then
      utils.is_attacking = false
      cooldown = player:getSwingDuration() * 0.5
    end
  end
  if cooldown > 0 then
    cooldown = cooldown - 1
  elseif cooldown == 0 then
    utils.BC = false
    cooldown = 0
  end
end)]]
function utils.difference(element, set)
  for _, value in pairs(set) do
    if value == element then
      return nil -- 要素が集合に含まれる場合、nilを返す
    end
  end
  return element -- 集合に含まれない場合、要素を返す
end

---@param frames keyframe[]
---@param time number
function utils.findFrames(frames, time)
  local n = #frames
  if time <= frames[1].timestamp then
    return frames[1], frames[1], frames[1], frames[1]
  end
  if time >= frames[n].timestamp then
    return frames[n], frames[n], frames[n], frames[n]
  end
  for i = 1, n - 1 do
    if frames[i].timestamp <= time and time < frames[i + 1].timestamp then
      local p1 = frames[i]
      local p2 = frames[i + 1]
      return p1, p2
    end
  end
end

-->====================[ Pathfinding algorithm ]====================<----MADE BY @SOOMUCHLAG
Nodes           = {} --Oh boi this is gonna be very (un)fun and (pa)in-sightful
Heurstics       = {}
VisitedNodes    = {}
NumOfIterations = 0
local posToExplore
local prevPosToExplore
local yes       = false
--Binary min heap wahtever queue by 4p5 <3
local queue     = {}

local function checkGroundboundness(pos)
  local x = -1
  local y = -1
  local z = -1
  local pass = false
  for i = 1, 27 do
    if world.getBlockState(pos + vec(x, y, z)):hasCollision() then
      pass = true
      break
    end
    x = x + 1
    if x == 2 then
      y = y + 1
      x = -1
    end
    if y == 2 then
      y = -1
      z = z + 1
    end
  end
  if not world.getBlockState(pos - vec(0, 1, 0)):hasCollision() then
    pass = false
  end
  return pass
end

local function push(n)
  local i = #queue + 1
  queue[i] = n
  while i > 1 do
    local p = i * 0.5
    p = p - p % 1
    if queue[p] > n then
      queue[i], queue[p] = queue[p], queue[i]
      i = p
    else
      break
    end
  end
end

--[[local function pop()
  local top = queue[1]
  queue[1] = queue[#queue]
  queue[#queue] = nil
  local i = 1
  while true do
    local l, r = 2 * i, 2 * i + 1
    local smallest = i
    if l <= #queue and queue[l] < queue[smallest] then smallest = l end
    if r <= #queue and queue[r] < queue[smallest] then smallest = r end
    if smallest == i then break end
    queue[i], queue[smallest] = queue[smallest], queue[i]
    i = smallest
  end
  return top
end]]

local function pop()
  local tlength = #queue
  local top = queue[1]
  queue[1] = queue[tlength]
  queue[tlength] = nil
  tlength = tlength - 1
  local i = 1
  while true do
    local l, r = 2 * i, 2 * i + 1
    local smallest = i
    if l <= tlength and queue[l] < queue[smallest] then smallest = l end
    if r <= tlength and queue[r] < queue[smallest] then smallest = r end
    if smallest == i then break end
    queue[i], queue[smallest] = queue[smallest], queue[i]
    i = smallest
  end
  return top
end

local function addNearbyNodes(pos, dest, force)
  local x = -1
  local y = -1
  local z = -1
  for i = 1, 27 do
    if not Nodes[pos.x + x] then
      Nodes[pos.x + x] = {}
    end
    if not Nodes[pos.x + x][pos.y + y] then
      Nodes[pos.x + x][pos.y + y] = {}
    end
    local continue = false

    if VisitedNodes[pos.x + x] == nil then
      continue = true
    end

    if not continue and VisitedNodes[pos.x + x][pos.y + y] == nil then
      continue = true
    end
    if not continue and VisitedNodes[pos.x + x][pos.y + y][pos.z + z] == nil then
      continue = true
    end

    if force then
      local condition1 = world.getBlockState(pos + vec(-0.01, 0, 0)):hasCollision() == true
      local condition2 = world.getBlockState(pos + vec(0.01, 0, 0)):hasCollision() == true
      local condition3 = world.getBlockState(pos + vec(0, 0, -0.01)):hasCollision() == true
      local condition4 = world.getBlockState(pos + vec(0, 0, 0.01)):hasCollision() == true

      -- 条件をテーブルにまとめる
      local conditions = { condition1, condition2, condition3, condition4 }

      -- 真（true）の数をカウントする
      local trueCount = 0
      for _, isTrue in ipairs(conditions) do
        if isTrue then
          trueCount = trueCount + 1
        end
      end

      -- 2つ以上満たした場合の処理
      if trueCount >= 2 then
        continue = false
      elseif not checkGroundboundness(pos + vec(x, y, z)) then
        continue = false
      end
    end

    if Nodes[pos.x + x][pos.y + y][pos.z + z] == nil and continue and not world.getBlockState(pos + vec(x, y, z)):hasCollision() then
      Nodes[pos.x + x][pos.y + y][pos.z + z] = {
        prevPos = pos,
        pos = pos + vec(x, y, z),
        heurstic = (pos + vec(x, y, z) - dest)
            :length() + math.sqrt(x * x + y * y + z * z)
      }
      push((pos + vec(x, y, z) - dest):length() + math.sqrt(x * x + y * y + z * z))
    end
    x = x + 1
    if x == 2 then
      y = y + 1
      x = -1
    end
    if y == 2 then
      y = -1
      z = z + 1
    end
  end
end
local posToFind

local function findPath()
  for i = 1, NumOfIterations do
    table.insert(utils.Path, posToFind)
    posToFind = VisitedNodes[posToFind.x][posToFind.y][posToFind.z].prevPos
    if VisitedNodes[posToFind.x][posToFind.y][posToFind.z].pos == VisitedNodes[posToFind.x][posToFind.y][posToFind.z].prevPos then
      break
    end
  end
end

function utils.pathfind(start, dest, force)
  if not yes then
    prevPosToExplore = posToExplore
    start = start:floor()

    dest = dest:floor()
    if NumOfIterations == 0 then
      prevPosToExplore = start
      Nodes[start.x] = {}
      Nodes[start.x][start.y] = {}
      VisitedNodes[start.x] = {}
      VisitedNodes[start.x][start.y] = {}
      Nodes[start.x][start.y][start.z] = { prevPos = start, pos = start }
      VisitedNodes[start.x][start.y][start.z] = { prevPos = start, pos = start }
      addNearbyNodes(start, dest, force)
    end


    local done = false
    local smallest = pop()

    for i, tblx in pairs(Nodes) do
      for j, tbly in pairs(tblx) do
        for k, data in pairs(tbly) do
          if data.heurstic == smallest then
            posToExplore = data.pos
            if not VisitedNodes[data.pos.x] then
              VisitedNodes[data.pos.x] = {}
            end
            if not VisitedNodes[data.pos.x][data.pos.y] then
              VisitedNodes[data.pos.x][data.pos.y] = {}
            end
            VisitedNodes[data.pos.x][data.pos.y][data.pos.z] = { prevPos = data.prevPos, pos = data.pos }
            Nodes[data.pos.x][data.pos.y][data.pos.z] = nil
            done = true
            break
          end
        end
        if done then
          break
        end
      end
      if done then
        break
      end
    end
    if posToExplore == dest then
      if not VisitedNodes[posToExplore.x] then
        VisitedNodes[posToExplore.x] = {}
      end
      if not VisitedNodes[posToExplore.x][posToExplore.y] then
        VisitedNodes[posToExplore.x][posToExplore.y] = {}
      end
      VisitedNodes[posToExplore.x][posToExplore.y][posToExplore.z] = { prevPos = prevPosToExplore, pos = posToExplore }
      Nodes[posToExplore.x][posToExplore.y][posToExplore.z] = nil
      posToFind = posToExplore

      findPath()
      yes = true
      return utils.Path
    end
    addNearbyNodes(posToExplore, dest, force)
  end



  NumOfIterations = NumOfIterations + 1
end

function utils.pathfindingReset()
  Nodes = {}
  Heurstics = {}
  VisitedNodes = {}
  utils.Path = {}
  queue = {}
  NumOfIterations = 0
  posToExplore = nil
  prevPosToExplore = nil
  yes = false
end

-- >====================[ MODEL UTILITIES ]====================<--
--[[---Sets the saturation value of your texture
---@param tex Texture
---@param value number
---@param x integer?
---@param y integer?
---@param width integer?
---@param height integer?
local function saturation(tex, value, x, y, width, height)
	if not tex then return end

	x, y = x or 0, y or 0
	if not (width or height) then
		width, height = tex:getDimensions():unpack()
	end

	value = value / 2
	local inner, outer = value + 0.5, -value + 0.5

	local mat = matrices.mat4(
		vec(inner, outer, outer, 0),
		vec(outer, inner, outer, 0),
		vec(outer, outer, inner, 0),
		vec(0, 0, 0, 1)
	):scale(inner)

	tex:applyMatrix(x, y, width, height, mat)
end]]
--Courtesy of @futaradragon on discord
-- function
function utils.ModelMapper(FiguraModelStructure, ModelMapperChain)
  local ModelMapper = ModelMapperChain or
      {}                                                                  -- init blank part or chain from the parent part
  if FiguraModelStructure:getType() == "GROUP" then                       -- check if the part that insert is GROUP type
    ModelMapper[FiguraModelStructure:getName()] =
        FiguraModelStructure                                              -- set object with current name to map the model
    for _, StructureModel in pairs(FiguraModelStructure:getChildren()) do -- find child part
      ModelMapper = utils.ModelMapper(StructureModel, ModelMapper)        -- chain child part and return the main mapper with new child key in the object
    end
  end
  return ModelMapper -- return mapper
end

function utils.copyModel(modelPart)
  local copy = modelPart:copy(modelPart:getName())
  for _, child in pairs(copy:getChildren()) do
    copy:removeChild(child):addChild(utils.copyModel(child))
  end
  return copy
end

function utils.move(target, destination, originalParent)
  target:moveTo(destination)
  local modelName = target:getName()
  if originalParent[modelName] ~= nil then
    originalParent:removeChild(target)
  end
end

--Courtesy of @auria. on discord
function utils.nearestEntity(point, radius)
  local best = math.huge
  local entity
  for _, e in pairs(world.getEntities(point - radius, point + radius)) do
    local dist = (e:getPos() - point):lengthSquared()
    if dist < best then
      best = dist
      entity = e
    end
  end
  return entity
end

local MAX_DISTANCE = 100
function utils.getLookTarget()
  local eyePos = client:getCameraPos()
  local lookDir = player:getLookDir()
  local endPos = eyePos + lookDir * MAX_DISTANCE

  -- Raycast for blocks
  local blockState, blockPos = raycast:block(eyePos, endPos, "VISUAL", "NONE")

  -- Raycast for entity (skip the player)
  local hitEntity, entityPos = raycast:entity(eyePos, endPos, function(e)
    return e ~= player
  end)

  -- If both hit, pick the closer one
  if blockPos and hitEntity and entityPos then
    local distBlock = (blockPos - eyePos):length()
    local distEntity = (entityPos - eyePos):length()
    if distEntity < distBlock then
      return entityPos, hitEntity
    else
      return blockPos, nil
    end

    -- If only block hit
  elseif blockPos then
    return blockPos, nil

    -- If only entity hit
  elseif hitEntity and entityPos then
    return entityPos, hitEntity
  end

  -- No hit: fallback to full reach
  return endPos, nil
end

function utils.getUnderwaterlevel(pos)
  local y = -1
  for i = -1, 2 do
    local bl = world.getBlockState(pos + vec(0, i, 0))
    if #bl:getFluidTags() >= 1 then
      local waterHeight = 0.85 - (bl.properties.level or 0) / 10
      y = i + waterHeight - pos.y % 1
    end
  end
  return y
end

--Courtesy of @4p5 on discord
function utils.isOnGround(entity, CLEARANCE)
  local pos = entity:getPos()
  local hitbox = entity:getBoundingBox().x_z / 2
  local min = pos - hitbox - vec(0, CLEARANCE, 0)
  local max = pos + hitbox
  local search_min = min:copy():floor()
  local search_max = max:copy():floor()
  local isInWater = #world.getBlockState(pos):getFluidTags() ~= 0
  if isInWater then
    return true
  else
    for x = search_min.x, search_max.x do
      for y = search_min.y, search_max.y do
        for z = search_min.z, search_max.z do
          local block_pos = vec(x, y, z)
          local block = world.getBlockState(block_pos)
          local boxes = block:getCollisionShape()
          for i = 1, #boxes do
            local box = boxes[i]
            local box1_min = box[1] + block_pos
            local box1_max = box[2] + block_pos

            if not (box1_max.x <= min.x or max.x <= box1_min.x or
                  box1_max.y <= min.y or max.y <= box1_min.y or
                  box1_max.z <= min.z or max.z <= box1_min.z) then
              return true
            end
          end
        end
      end
    end
  end
  return false
end

local function Boost(dir)
  return "[" .. dir.x .. "d, " .. dir.y .. "d, " .. dir.z .. "d]"
end

function utils.directionToEulerAngles(dirX, dirY, dirZ)
  local yaw = math.atan(dirZ, dirX)
  local pitch = math.asin(-dirY)
  return yaw, pitch
end

function utils.rotateEntityAccordingToVelocity(velocity)
  local dir = vec(velocity.x, velocity.y, velocity.z):normalize()
  if dir.y > 180 then dir.y = dir.y - 360 end
  local yaw, pitch = utils.directionToEulerAngles(dir.x, dir.y, dir.z)
  local yawDeg = math.deg(yaw)
  local pitchDeg = math.deg(pitch)
  return yawDeg, pitchDeg
end

--[[function utils.entityRayCasted(pos, height, dir, radian, debugOn)
  local raystart = pos + vec(0, height, 0)
  local rayend = raystart + dir * radian
  local block, blockPos = raycast:block(raystart, rayend)
  if debugOn then
    utils.line(raystart, blockPos)
  end
  local hitEntity, entityPos = raycast:entity(raystart, rayend, C.noOwner)

  -- If both hit, pick the closer one
  if blockPos and hitEntity and entityPos then
    local distBlock = (blockPos - raystart):length()
    local distEntity = (entityPos - raystart):length()
    if distEntity < distBlock then
      return entityPos, hitEntity
    else
      return blockPos, nil
    end

    -- If only block hit
  elseif blockPos then
    return blockPos, nil

    -- If only entity hit
  elseif hitEntity and entityPos then
    return entityPos, hitEntity
  end

  -- No hit: fallback to full reach
  return rayend, nil
end]]

local function formatNumber(x)
  local sign = x < 0 and '-' or ''
  x = math.abs(x)
  local decimals = tostring(math.floor((x % 1) * 10000) / 10000)
  if decimals == '0' then
    return sign .. tostring(math.floor(x))
  end
  return sign .. tostring(math.floor(x)) .. '.' .. decimals:gsub('^0%.', '')
end
local function canRunCommands()
  return host:isHost() and player:getPermissionLevel() >= 2
end

local function sendCommand(command)
  if #command >= 256 then return end
  host:sendChatCommand(command)
  host:setChatMessage(1, nil)
end
function utils.entityAttack(entity, vel, damage)
  if entity ~= nil then
    if not C.noOwner(entity) then return end
    if not canRunCommands() then return end
    local id = entity:getType()
    if not entity:isLiving() and id ~= 'minecraft:boat' and not id:match('minecart') then
      return
    end
    if entity.getGamemode and entity:getGamemode() then return end
    if entity:getNbt().HurtTime == 0 and entity:getDeathTime() == 0 then
      sendCommand("execute as " .. entity:getUUID() .. " run execute as @s[nbt={HurtTime:0s}] run damage " ..
        entity:getUUID() .. " " .. formatNumber(damage) .. " minecraft:player_attack by @s")

      sendCommand("/data modify entity " .. entity:getUUID() .. " Motion set value " .. Boost(vel * 2))

      -- Visual/audio feedback
      sounds:playSound("minecraft:block.lava.extinguish", entity:getPos(), 0.5, 1.5)
      particles:newParticle("minecraft:crit", entity:getPos() + vec(0, 1, 0))
      return true
    end
  end
  return false
end

--[[local slamingR = false
local slamingL = false
local swingR = 1
local swingL = 1
local main = 1
local off = 1
function utils.bettercombatRot(part)
  if player:getHeldItem(player:isLeftHanded()) and not player:getHeldItem(not player:isLeftHanded()) then ---only right
    main = 1
    off = 0.25
  elseif player:getHeldItem(not player:isLeftHanded()) and not player:getHeldItem(player:isLeftHanded()) then ---only left
    main = 0.25
    off = 1
  else
    main = 1
    off = 1
  end
  local R = vanilla_model.RIGHT_ARM:getOriginRot() * (utils.BC and 1 or utils.is_gun and 1 or 0) * vec(1, main, main)
  local PR = vanilla_model.RIGHT_LEG:getOriginPos().y
  local L = vanilla_model.LEFT_ARM:getOriginRot() * (utils.BC and 1 or utils.is_gun and 1 or 0) * vec(1, off, off)
  local PL = vanilla_model.LEFT_LEG:getOriginPos().y
  if not utils.BC then
    swingR = 0
    swingL = 0
  end
  -- >====================[ RIGHT ]====================<--
  if R.x > 100 then
    slamingR = true
  end

  if R.x < 90 then
    slamingR = false
  end

  if R.x < 0 then
    swingR = 180
  end

  if R.y > 50 and R.y < 60 then
    swingR = 90
  end
  if R.y < -50 and R.y > -60 then
    swingR = -90
  end

  if math.abs(R.y) < 30 then
    if slamingR and PR < 0 and PL < -0.6 then
      swingR = 0
    end
  end

  if R.y > 60 then
    swingR = -90
  end
  if R.y < -60 then
    swingR = 90
  end
  -- >====================[ LEFT ]====================<--
  if L.x > 100 then
    slamingL = true
  end

  if L.x < 90 then
    slamingL = false
  end

  if L.x < 0 then
    swingL = 180
  end

  if L.y > 50 and L.y < 60 then
    swingL = 90
  end
  if L.y < -50 and L.y > -60 then
    swingL = -90
  end

  if math.abs(L.y) < 30 then
    if slamingL and PL < 0 and PR < -0.6 then
      swingL = 0
    end
  end

  if L.y > 60 then
    swingL = -90
  end
  if L.y < -60 then
    swingL = 90
  end

  if part == "head" then
    if utils.is_sitting then
      return vec(0, 0, 0)
    else
      return vanilla_model.HEAD:getOriginRot()
    end
  elseif part == "RA" then
    return R + vec(0
    , utils.is_gun and 0 or math.clamp((PL + PR) * 45, -15, 15)
    , 0)
  elseif part == "RH" then
    return vec(utils.is_gun and 0 or (-90 * (utils.BC and 1 or 0)),
      utils.is_gun and 0 or
      (R.y > 60 and 90 or
        (R.y < -60 and -90 or
          (slamingR and swingR or
            swingR)
        )))
  elseif part == "LA" then
    return L + vec(0
    , utils.is_gun and 0 or math.clamp((PL + PR) * 45, -15, 15)
    , 0)
  elseif part == "LH" then
    return vec(-90 * (utils.BC and 1 or 0),
      L.y > 60 and 90 or
      (L.y < -60 and -90 or
        (slamingL and swingL or
          swingL)
      ))
  end
end]]
function utils.rngV(scale)
  return vec((math.random() - 0.5) * scale, (math.random() - 0.5) * scale, (math.random() - 0.5) * scale)
end

-- >====================[ NBT UTILITIES ]====================<--
function utils.hasEffect(effect_name, lvl, mod)
  if not host:isHost() then return end
  if mod == nil then
    mod = "minecraft"
  end
  if not lvl and effect_name then
    for _, effect in ipairs(host:getStatusEffects()) do
      if effect.name == "effect." .. mod .. "." .. effect_name then return true end
    end
  elseif type(lvl) == "number" and effect_name then
    for _, effect in ipairs(host:getStatusEffects()) do
      if effect.name == "effect." .. mod .. "." .. effect_name and effect.amplifier == lvl then return true end
    end
  end
  return false
end

function utils.hasEnchant(item, enchantment, lvl)
  local tags = item:getTag().Enchantments
  if not tags then return false end
  if client:compareVersions(client:getVersion(), "1.20.5") >= 0 then
    if not lvl then
      return tags.levels[enchantment] ~= nil
    elseif type(lvl) == "number" then
      return tags.levels[enchantment] ~= nil and tags.levels[lvl] ~= nil
    end
  else
    if not lvl and tags then
      for _, enchant in pairs(tags) do
        if enchant.id == enchantment then return true end
      end
    elseif type(lvl) == "number" and tags then
      for _, enchant in pairs(tags) do
        if enchant.id == enchantment and enchant.lvl == lvl then return true end
      end
    end
  end
  return false
end

-- >====================[ SOUNDS & VFX UTILITIES ]====================<--
function utils.STEPSOUND(pos)
  sounds:playSound("minecraft:item.armor.equip_netherite", pos, 0.5, 3)
  sounds:playSound("minecraft:entity.polar_bear.step", pos, 0.5, 1)
end

function utils.SHOTSOUND(pos)
  sounds:playSound("minecraft:item.trident.throw", pos, 1, 0.8)
  sounds:playSound("minecraft:block.respawn_anchor.deplete", pos, 1, 1.8)
  sounds:playSound("minecraft:item.trident.return", pos, 1, 1)
end

function utils.BEAMBBOOMSOUND(pos)
  particles:newParticle("minecraft:sonic_boom", pos):scale(7.5):lifetime(40)
  particles:newParticle("minecraft:sonic_boom", pos):scale(15):lifetime(40)
  particles:newParticle("minecraft:sonic_boom", pos):scale(25):lifetime(40)
  particles:newParticle("minecraft:sonic_boom", pos):scale(40):lifetime(40)
  sounds["block.beacon.deactivate"]:attenuation(2):pos(pos):play()
  sounds["entity.wither.death"]:volume(0.25):pitch(10):attenuation(2):pos(pos):play()
end

function utils.SIUSIU(pos)
  if world:getTime() % 3 == 0 then
    sounds:playSound("minecraft:block.bubble_column.whirlpool_inside", pos, 0.35, 5):attenuation(1.5)
  end
end

function utils.BOOMSOUND(pos)
  for _ = 1, 32 do
    particles['minecraft:flame']:gravity(0.25):size(1):lifetime(math.random(5, 20)):spawn()
        :scale(math.random() * 2 - 1)
        :pos(pos + (vec(math.random(), math.random() + 1, math.random()) * 2 - 1))
  end
  for _ = 1, 1 do
    particles['minecraft:explosion']:lifetime(math.random(5, 20)):spawn()
        :pos(pos + (vec(math.random(), math.random() + 1, math.random()) * 2 - 1))
  end
  sounds:playSound("minecraft:entity.creeper.primed", pos, 0.75, 1)
  sounds:playSound("minecraft:entity.generic.explode", pos, 0.75, 0.75)
end

function utils.HITGROUND(pos)
  sounds:playSound("minecraft:entity.iron_golem.hurt", pos:add(0, 1, 1), 0.5, 0.5)
  sounds:playSound("minecraft:block.ancient_debris.break", pos:add(0, 1, 0.8), 0.5, 0.4)
  sounds:playSound("minecraft:item.armor.equip_netherite", pos:add(0, 1, 1), 0.5, 0.5)
end

function utils.SWINGSOUND(pos)
  if not utils.is_holding_sword then return end
  sounds:playSound("minecraft:entity.witch.throw", pos:add(0, 1, 1), 0.5,
    1 + (math.random() - 0.5) * 0.2)
  sounds:playSound("minecraft:item.trident.throw", pos:add(0, 1, 0.8), 0.5,
    1 + (math.random() - 0.5) * 0.2)
  --sounds:playSound("minecraft:item.axe.scrape", pos:add(0, 1, 1), 1,1 + (math.random() - 0.5) * 0.2)
  sounds:playSound("minecraft:entity.iron_golem.attack", pos:add(0, 1, 1), 0.5,
    1 + (math.random() - 0.5) * 0.2)
end

function utils.PARRYSOUND(pos)
  sounds:playSound("minecraft:block.sculk.hit", pos, 0.25, 1, false)
  sounds:playSound("minecraft:block.wood.break", pos, 0.25, 1, false)
  sounds:playSound("minecraft:block.anvil.land", pos, 0.25, 1, false)
end

--[[function utils.line(pos1, pos2)
  local distance = (pos2 - pos1):length()
  local direction = (pos2 - pos1):normalize()
  for i = 0, distance, 0.1 do
    local pos = pos1 + direction * i
    particles:newParticle('minecraft:end_rod', pos):setSize(0.5):setLifetime(0):setColor(math.lerp(vec(1, 1, 0),
      vec(1, 0, 0), distance * 0.1))
  end
end

local function Particle(name, pos) ---boom
  sounds:playSound("entity.fox.teleport", getModelWorldPos(pos), 0.25, 1.5)
  local customPos = getModelWorldPos(pos)
  local X = getModelWorldPos(pos):add(0, 2, 0):sub(customPos):normalize()
  local Y = getModelWorldPos(pos):add(0, 0, 0):sub(customPos):normalize()
  local Z = getModelWorldPos(pos):add(0, -2, 0):sub(customPos):normalize()
  local offsetPos = X:copy():scale(math.random() * 2 - 1):add(Y:copy():scale(math.random() * 2 - 1)):add(Z
    :copy():scale(math.random() * 1))
  for _ = 1, 32 do
    particles[name]
        :pos(customPos:copy():add(offsetPos) + (vec(math.random(), math.random(), math.random()) * 3 - 1) * 0.2)
        :velocity(offsetPos:copy():scale(-0.1))
        :gravity(0)
        :size(0.5)
        :lifetime(math.random(5, 10))
        :color(math.lerp(vec(1, 1, 0), vec(1, 0, 0), offsetPos:copy()))
        :spawn()
  end
end]]

function utils.TELEPORT(name, pos1, pos2)
  Particle(name, pos1)
  Particle(name, pos2)
  utils.line(getModelWorldPos(pos1), getModelWorldPos(pos2))
end

return utils
