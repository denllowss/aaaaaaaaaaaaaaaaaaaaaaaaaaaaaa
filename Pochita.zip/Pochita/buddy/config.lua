--[[__  ___                      __
   /  |/  /_  ________________ _/ /_
  / /|_/ / / / / ___/ ___/ __ `/ __/
 / /  / / /_/ (__  ) /__/ /_/ / /_
/_/  /_/\__,_/____/\___/\__,_/\__]]
local config = {
  Anchor = models.model.root.RightArm.PochitaPivot, --<========= Change here to spot where you want buddy to ride
  Offset = vec(0, -0.9, -0.1),
  Input  = {
    Detect = keybinds:newKeybind("Switch entity Target", "key.keyboard.i"),
  },

}
function config.noOwner(entity)
  local id = entity:getType()
  return entity ~= player and entity:isLiving() and
      id == 'minecraft:zombie' or
      id == 'minecraft:husk' or
      id == 'minecraft:drowned' or
      id == 'minecraft:giant' or
      id == 'minecraft:zombified_piglin' or
      id == 'minecraft:piglin' or
      id == 'minecraft:zombified_zoglin' or
      id == 'minecraft:zoglin' or
      id == 'minecraft:piglin_brute' or
      id == 'minecraft:zombie_villager' or
      id == 'minecraft:skeleton' or
      id == 'minecraft:wither_skeleton' or
      id == 'minecraft:stray' or
      id == 'minecraft:bogged' or
      id == 'minecraft:pillager' or
      id == 'minecraft:slime' or
      id == 'minecraft:magma_cube' or
      id == 'minecraft:vindicator' or
      id == 'minecraft:witch' or
      id == 'minecraft:evoker' or
      id == 'minecraft:ravager' or
      id == 'minecraft:enderman' or
      id == 'minecraft:endermite' or
      id == 'minecraft:ender_dragon' or
      id == 'minecraft:creaking' or
      id == 'minecraft:warden' or
      id == 'minecraft:wither' or
      id == 'minecraft:elder_guardian' or
      id == 'minecraft:guardian' or
      id == 'minecraft:ghast' or
      id == 'minecraft:phantom' or
      id == 'minecraft:vex' or
      id == 'minecraft:creeper' or
      id == 'minecraft:spider' or
      id == 'minecraft:blaze' or
      id == 'minecraft:breeze' or
      id == 'minecraft:shulker' or
      id == 'minecraft:endermite' or
      id == 'minecraft:ghast' or
      id == 'minecraft:phamtom' or
      id == 'minecraft:vex' or
      id == 'minecraft:blaze' or
      id == 'minecraft:breeze'
end

return config
