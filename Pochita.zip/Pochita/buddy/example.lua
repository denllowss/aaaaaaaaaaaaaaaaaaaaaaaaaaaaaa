local dronezAPI = require("buddy.dronezAPI")

vanilla_model.PLAYER:setVisible(false)


function events.entity_init()
	-->====================[ Homies ]====================<--
	dronezAPI.registerMesh("gura", models.buddy.pochita) --1
	dronezAPI.newDrone("gura", true, player:getPos() + vec(0, player:getBoundingBox().y, 0), nil, false,
		{
			init = function(particle)
				local opts = particle.options
				opts.entitytoentitycolloff = 1.25
			end,
			ticker = function(particle)
				particle.lifetime = 2
				dronezAPI.AITicker(particle)
			end,
			renderer = function(particle, dt)
				dronezAPI.AIRenderer(particle, dt)
			end
		})
end
